if(`test -n "-L/storage/Users/currentUser/.harmonybrew/opt/libxml2/lib -lxml2 -L/storage/Users/currentUser/.harmonybrew/opt/zlib-ng-compat/lib -lz -lm"`) then

if(${?LD_LIBRARY_PATH}) then
    setenv LD_LIBRARY_PATH ${LD_LIBRARY_PATH}:-L/storage/Users/currentUser/.harmonybrew/opt/libxml2/lib -lxml2 -L/storage/Users/currentUser/.harmonybrew/opt/zlib-ng-compat/lib -lz -lm
else
   setenv LD_LIBRARY_PATH -L/storage/Users/currentUser/.harmonybrew/opt/libxml2/lib -lxml2 -L/storage/Users/currentUser/.harmonybrew/opt/zlib-ng-compat/lib -lz -lm
endif

endif
