# rhdf5

<img align = "right" src="man/figures/logo.svg" width="120" />

This R/Bioconductor package provides an interface between HDF5 and R. HDF5's main features are the ability to store and access very large and/or complex datasets and a wide variety of metadata on mass storage (disk) through a completely portable file format. The rhdf5 package is thus suited for the exchange of large and/or complex datasets between R and other software package, and for letting R applications work on datasets that are larger than the available RAM.

## Current Status

| GitHub Actions | Bioconductor Build Sysytem | Test Coverage |
| ------------- |-------------| ----- |
| [![Package Checks](https://github.com/grimbough/rhdf5/actions/workflows/main.yml/badge.svg)](https://github.com/grimbough/rhdf5/actions/workflows/main.yml) | [![BioC Status](https://bioconductor.org/shields/build/devel/bioc/rhdf5.svg)](http://bioconductor.org/checkResults/devel/bioc-LATEST/rhdf5/) | [![Codecov](http://img.shields.io/codecov/c/github/grimbough/rhdf5.svg)](https://codecov.io/gh/grimbough/rhdf5) |

## Contact

For bug reports, please register an [issue](https://github.com/grimbough/rhdf5/issues) here on Github. For usage queries please post a question on the [Bioconductor Support Forum](https://support.bioconductor.org/p/new/post/?tag_val=rhdf5).


## Funding

Funding for continued development and maintenance of this package has been provided by the German Network for Bioinformatics Infrastructure & the Chan Zuckerberg Initiative.

|    |    |
|:---|---:|
|<a href="http://www.denbi.de"><img src="https://tess.elixir-europe.org/system/content_providers/images/000/000/063/original/deNBI_Logo_rgb.jpg" width="400" align="left"></a>|<img src="https://image4.owler.com/logo/chan-zuckerberg-initiative_owler_20160616_114930_original.png" width="257" align="right">|
